import React from 'react'

const PrepareDevice = () => {
  return (
    <div>PrepareDevice</div>
  )
}

export default PrepareDevice