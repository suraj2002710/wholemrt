import React from 'react'

const CallFlowCaptures = () => {
  return (
    <div>CallFlowCaptures</div>
  )
}

export default CallFlowCaptures