import React from 'react'

const CreateAgent = () => {
  return (
    <div>CreateAgent</div>
  )
}

export default CreateAgent