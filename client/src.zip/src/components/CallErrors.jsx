import React from 'react'

const CallErrors = () => {
  return (
    <div>CallErrors</div>
  )
}

export default CallErrors