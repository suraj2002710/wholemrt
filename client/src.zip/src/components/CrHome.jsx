import React from 'react'

const CrHome = () => {
  return (
    <div>CrHome</div>
  )
}

export default CrHome