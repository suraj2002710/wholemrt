import React from 'react'

const DialerPage = () => {
  return (
    <div>DialerPage</div>
  )
}

export default DialerPage